<?php
/**
 * Century ToolKit Unstaller
 *
 * Uninstalling Century ToolKit
 *
 * @author      ThemeCentury
 * @category    Core
 * @package     Century ToolKit/Uninstaller
 * @version     1.0.0
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Uninstall function goes here
